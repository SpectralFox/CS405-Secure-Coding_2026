// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept> // needed for standard exceptions execution

//Creating an exception calss to catch all potential exceptions while program is running.
class CustomException : public std::exception {
private:
    std::string message;
public:
    // Constructor accepts a custom error message
    CustomException(const std::string& msg) : message(msg) {}

    // Override what() to return our custom message
    const char* what() const noexcept override {
        return message.c_str();
    }
};
bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    throw std::runtime_error("Error has occurred, run for the hills!!"); // This throws a general exception statement that is not associated to anything particular.
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;
    //exception handler that utilizes try-catch block 
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        // Catch standard exceptions and display the error message
        // This prevents the application from crashing and informs the user
        std::cout << "Exception caught in do_custom_application_logic: " << e.what() << std::endl;
    }
    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    class CustomException : public std::exception {
    private:
        std::string message;
    public:
        CustomException(const std::string& msg) : message(msg) {}
        const char* what() const noexcept override {
            return message.c_str();
        }
    };
    // Throwing custom except.
    throw CustomException("Custom exception thrown from do_custom_application_logic");

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0.0f) {
        throw std::invalid_argument("Division by zero is not allowed");
    }
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e) {
        std::cout << "Exception caight in do_division : " << e.what() << std::endl;
    }
}


int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    try{ 
        do_division();
        do_custom_application_logic();
}
catch (const CustomException& e) { 
    // First, catch our custom exception specifically
    std::cout << "Custom Exception caught in main : " << e.what() << std::endl;
}
catch (const std::exception& e) {
    // Then catch all standard exceptions
    std::cout << "Standard Exception caught in main : " << e.what() << std::endl;
}
catch (...) {
    // Finally, catch-all handler for any non-standard exceptions
    std::cout << "Unknown Exception caught in main" << std::endl;
}

return 0;
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu